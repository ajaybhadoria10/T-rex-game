# AI-T-Rex-Game-Clone
It is a voice activated game and the objects are called by pressing the mouse click. The project is in working phase.
